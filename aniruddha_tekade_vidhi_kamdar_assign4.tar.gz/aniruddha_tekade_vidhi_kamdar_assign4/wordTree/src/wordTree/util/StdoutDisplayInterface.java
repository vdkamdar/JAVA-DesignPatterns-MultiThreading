package wordTree.util;

import wordTree.myTree.MyTree;

/**
 * @version 4.0
 * @author Aniruddha Tekade & Vidhi Kamdar Submitted on November 8th, 2017.
 */
public interface StdoutDisplayInterface {

    public void writeToScreen();
}
